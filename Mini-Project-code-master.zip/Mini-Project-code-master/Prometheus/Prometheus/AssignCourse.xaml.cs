﻿using Prometheus_Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for AssignCourse.xaml
    /// </summary>
    public partial class AssignCourse : Window
    {
        List<Student> StudentList;
        public AssignCourse()
        {
            InitializeComponent();
            BindLeftList();
        }

        
        private void ComboBox_Loaded(object sender, RoutedEventArgs e)
        {
            // ... A List.
            List<string> data = new List<string>();
            data.Add("--Select Course--");
            data.Add("Mathematics");
            data.Add("Science");
            data.Add("English");


            // ... Get the ComboBox reference.
            var comboBox = sender as ComboBox;

            // ... Assign the ItemsSource to the List.
            comboBox.ItemsSource = data;

            // ... Make the first item selected.
            comboBox.SelectedIndex = 0;
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            // ... Get the ComboBox.
            var comboBox = sender as ComboBox;

            // ... Set SelectedItem as Window Title.
            string value = comboBox.SelectedItem as string;
            this.Title = "Selected: " + value;

        }
        public void Window_Loaded(object sender, RoutedEventArgs e)
        {
           
        }
        int currentItemIndex;
        string currentItemText;

        public DataTable BindLeftList()
        {
            SqlConnection ConnObj = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser");
            SqlCommand Command = new SqlCommand("Select FName from Group1.Student", ConnObj);
            DataTable tea = new DataTable("Student");
            //Command.CommandType = CommandType.StoredProcedure;
            List<Student> studentList = new List<Student>();
            ConnObj.Open();
            SqlDataReader teaReader = Command.ExecuteReader();
            if (teaReader.HasRows)
            {
                tea.Load(teaReader);

            }
            return tea;
              
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            if (LeftlistBox.SelectedIndex > -1)
            {
                currentItemText = LeftlistBox.SelectedValue.ToString();
                currentItemIndex = LeftlistBox.SelectedIndex;

                RightlistBox.Items.Add(currentItemText);
                if (StudentList != null)
                {
                    StudentList.RemoveAt(currentItemIndex);
                    LeftlistBox.ItemsSource = null;
                    LeftlistBox.ItemsSource = StudentList.Select(x => x.FName);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Please Select An Item To Remove");
            }
        }

        
        private void btn_remove_Click(object sender, RoutedEventArgs e)
        {
            if (RightlistBox.SelectedIndex > -1)
            {
                currentItemText = RightlistBox.SelectedValue.ToString();
                currentItemIndex = RightlistBox.SelectedIndex;

                Student Student = new Student();
                Student.FName = currentItemText;
                StudentList.Add(Student);
                RightlistBox.Items.RemoveAt(RightlistBox.Items.IndexOf(RightlistBox.SelectedItem));

                LeftlistBox.ItemsSource = null;
                LeftlistBox.ItemsSource = StudentList.Select(x => x.FName);

            }
            else
            {
                System.Windows.MessageBox.Show("Please Select An Item To Remove");
            }
        }



        
    }
}
        
        