﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prometheus_Exeception
{
    public class PExeception : ApplicationException
    {
        public PExeception()
            : base()
        { }

        public PExeception(string message)
            : base(message)
        { }
    }
}
